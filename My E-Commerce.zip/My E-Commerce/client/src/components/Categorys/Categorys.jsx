import { useEffect, useContext } from "react";
import Category from "../Home/Category/Category";
import { fetchDataFromApi } from "../../utils/api";
import { Context } from "../../utils/context";

import "./Categorys.scss";

const Categorys = () => {

    const {categories, setCategories} = useContext(Context);

    useEffect(() => {

        const getCategories = () => {
            fetchDataFromApi("/api/categories?populate=*").then((res) => {
                console.log(res)
                setCategories(res)
            });
        };

        
        getCategories();
    }, [setCategories]);

    return (
        <div className="layout">
            <div className="categorys-container">
                <div className="heading">All Categorys</div>
                <div className="categorys">
                    <Category categories={categories} />
                </div>
            </div>
        </div>
        
        
        );
};

export default Categorys;